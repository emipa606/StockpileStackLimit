﻿using HarmonyLib;
using RimWorld;
using Verse;

namespace StockpileStackLimit
{
    [HarmonyPatch(typeof(ListerMergeables), "ShouldBeMergeable")]
    public class ShouldBeMergeablePatch
    {
        static void Postfix(Thing t, ref bool __result)
        {
            if (__result == true)
                if (Limits.HasStackLimit(t))
                {
                    __result = false;
                }
                else if (t.stackCount == Limits.CalculateStackLimit(t))
                {
                    __result = false;
                }
                else
                {
                    __result = true;
                }
            //if (t.IsForbidden(Faction.OfPlayer))
            //{
            //    __result = false;
            //}
            //else if (!Limits.HasStackLimit(t))
            //{
            //    __result = false;
            //}
            //else if (t.stackCount == Limits.CalculateStackLimit(t))
            //{
            //    __result = false;
            //}
            //else
            //    __result = true;
            //return false;
        }
    }
}
